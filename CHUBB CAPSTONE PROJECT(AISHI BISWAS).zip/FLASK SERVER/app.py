from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
from matplotlib import cm

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mssql+pymssql://inf_dev_hr:inf_dev_hr@laptop-pkp0i4u6:1433/hr'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class DimDepartment(db.Model):
    __tablename__ = 'dim_department'
    DEPARTMENT_ID = db.Column(db.Integer, primary_key=True)
    DEPARTMENT_TITLE = db.Column(db.String(100), nullable=False)

class DimJobTitle(db.Model):
    __tablename__ = 'dim_job_title'
    JOB_TITLE_ID = db.Column(db.Integer, primary_key=True)
    JOB_TITLE = db.Column(db.String(100), nullable=False)

class DimGender(db.Model):
    __tablename__ = 'dim_gender'
    GENDER_ID = db.Column(db.Integer, primary_key=True)
    GENDER = db.Column(db.String(50), nullable=False)

class DimEthnicity(db.Model):
    __tablename__ = 'dim_ethnicity'
    ETHNICITY_ID = db.Column(db.Integer, primary_key=True)
    ETHNICITY = db.Column(db.String(50), nullable=False)

class DimEmploymentType(db.Model):
    __tablename__ = 'dim_employment_type'
    EMPLOYMENT_TYPE_ID = db.Column(db.Integer, primary_key=True)
    EMPLOYMENT_TYPE = db.Column(db.String(50), nullable=False)

class DimPayYear(db.Model):
    __tablename__ = 'dim_pay_year'
    PAY_YEAR_ID = db.Column(db.Integer, primary_key=True)
    PAY_YEAR = db.Column(db.Integer, nullable=False)

class FactEmployeePay(db.Model):
    __tablename__ = 'fact_employee_pay'
    FACT_ID = db.Column(db.Integer, primary_key=True)
    DEPARTMENT_ID = db.Column(db.Integer, db.ForeignKey('dim_department.DEPARTMENT_ID'), nullable=False)
    JOB_TITLE_ID = db.Column(db.Integer, db.ForeignKey('dim_job_title.JOB_TITLE_ID'), nullable=False)
    GENDER_ID = db.Column(db.Integer, db.ForeignKey('dim_gender.GENDER_ID'), nullable=False)
    ETHNICITY_ID = db.Column(db.Integer, db.ForeignKey('dim_ethnicity.ETHNICITY_ID'), nullable=False)
    EMPLOYMENT_TYPE_ID = db.Column(db.Integer, db.ForeignKey('dim_employment_type.EMPLOYMENT_TYPE_ID'), nullable=False)
    PAY_YEAR_ID = db.Column(db.Integer, db.ForeignKey('dim_pay_year.PAY_YEAR_ID'), nullable=False)
    TOTAL_PAY = db.Column(db.Numeric(15, 2), nullable=False)
    REGULAR_PAY = db.Column(db.Numeric(15, 2))
    OVERTIME_PAY = db.Column(db.Numeric(15, 2))
    BENEFIT_PAY = db.Column(db.Numeric(15, 2))
    CITY_RETIREMENT_CONTRIBUTIONS = db.Column(db.Numeric(15, 2))

def plot_to_base64(plt):
    buf = io.BytesIO()
    plt.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    img_bytes = buf.read()
    base64_string = base64.b64encode(img_bytes).decode("utf-8")
    buf.close()
    plt.clf()  
    return base64_string

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/visualizations')
def visualizations():
    data = db.session.query(FactEmployeePay, DimDepartment, DimJobTitle, DimGender, DimEthnicity, DimEmploymentType, DimPayYear) \
        .join(DimDepartment, FactEmployeePay.DEPARTMENT_ID == DimDepartment.DEPARTMENT_ID) \
        .join(DimJobTitle, FactEmployeePay.JOB_TITLE_ID == DimJobTitle.JOB_TITLE_ID) \
        .join(DimGender, FactEmployeePay.GENDER_ID == DimGender.GENDER_ID) \
        .join(DimEthnicity, FactEmployeePay.ETHNICITY_ID == DimEthnicity.ETHNICITY_ID) \
        .join(DimEmploymentType, FactEmployeePay.EMPLOYMENT_TYPE_ID == DimEmploymentType.EMPLOYMENT_TYPE_ID) \
        .join(DimPayYear, FactEmployeePay.PAY_YEAR_ID == DimPayYear.PAY_YEAR_ID).all()

    records = [
        {
            "Department": d.DEPARTMENT_TITLE,
            "Job Title": jt.JOB_TITLE,
            "Gender": g.GENDER,
            "Ethnicity": e.ETHNICITY,
            "Employment Type": et.EMPLOYMENT_TYPE,
            "Pay Year": py.PAY_YEAR,
            "Total Pay": f.TOTAL_PAY,
            "Regular Pay": f.REGULAR_PAY,
            "Overtime Pay": f.OVERTIME_PAY,
            "Benefit Pay": f.BENEFIT_PAY,
            "City Retirement Contributions": f.CITY_RETIREMENT_CONTRIBUTIONS
        }
        for f, d, jt, g, e, et, py in data
    ]
    fact_employee_pay = pd.DataFrame(records)

    visualizations = []

    plt.figure(figsize=(15, 8))
    fact_employee_pay_cleaned = fact_employee_pay[~fact_employee_pay['Gender'].isin(['UNKNOWN', 'NA', 'OTHER'])]
    sns.barplot(x='Pay Year', y='Total Pay', hue='Gender', data=fact_employee_pay_cleaned, palette='Set1')
    plt.xticks(rotation=90, ha='right')
    plt.title('Impact of Gender on Pay Distribution Over the Years')
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(15, 8))
    fact_employee_pay_filtered = fact_employee_pay[~fact_employee_pay['Ethnicity'].isin(['UNKNOWN', 'NA', 'OTHER'])]
    sns.barplot(
        x='Ethnicity', 
        y='Total Pay', 
        data=fact_employee_pay_filtered, 
        palette='Set2'
    )
    plt.xticks(rotation=90, ha='right')
    plt.title('Comparison of Total Pay by Ethnicity')
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(15, 8))
    pay_disparity = fact_employee_pay.groupby(['Ethnicity', 'Gender'])['Total Pay'].mean().unstack()
    pay_disparity['Disparity'] = pay_disparity['MALE'] - pay_disparity['FEMALE']
    pay_disparity['Disparity'] = pd.to_numeric(pay_disparity['Disparity'], errors='coerce')
    pay_disparity['Disparity'].fillna(0, inplace=True)
    sns.heatmap(pay_disparity[['Disparity']], annot=True, cmap="coolwarm")
    plt.title("Pay Disparity Between Genders Across Ethnicities")
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(15, 8))
    fact_employee_pay['Total Pay'] = fact_employee_pay['Total Pay'].astype(float)
    top_earners = fact_employee_pay[fact_employee_pay['Total Pay'] >= fact_employee_pay['Total Pay'].quantile(0.9)]
    representation_top = top_earners.groupby(['Ethnicity', 'Gender']).size().reset_index(name='Count')
    sns.barplot(data=representation_top, x='Count', y='Ethnicity', hue='Gender', orient='h')
    plt.title("Representation in Top 10% Earners by Ethnicity and Gender")
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))  

    plt.figure(figsize=(15, 8))
    sns.violinplot(x='Employment Type', y='Total Pay', data=fact_employee_pay, palette='muted')
    plt.xticks(rotation=90, ha='right')
    plt.title('Pay Distribution by Employment Type')
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(15, 8))
    fact_employee_pay_filtered = fact_employee_pay[~fact_employee_pay['Ethnicity'].isin(['UNKNOWN', 'NA', 'OTHER'])]
    fact_employee_pay_filtered = fact_employee_pay_filtered[~fact_employee_pay_filtered['Gender'].isin(['UNKNOWN', 'NA', 'OTHER'])]
    sns.barplot(
    x='Ethnicity', 
    y='Total Pay', 
    hue='Gender', 
    data=fact_employee_pay_filtered, 
    palette='Set2'
    )
    plt.xticks(rotation=90, ha='right')
    plt.title('Comparison of Total Pay by Gender and Ethnicity')
    plt.xticks(fontsize=8)
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(20, 8))
    fact_employee_pay_clean = fact_employee_pay.dropna(subset=['Job Title', 'Gender', 'Ethnicity', 'Total Pay'])
    fact_employee_pay_clean['Gender and Ethnicity'] = fact_employee_pay_clean['Gender'] + ' - ' + fact_employee_pay_clean['Ethnicity']
    plt.figure(figsize=(14, 8))
    sns.barplot(x='Job Title', y='Total Pay', hue='Gender and Ethnicity', data=fact_employee_pay_clean, ci=None, palette='Set1', estimator='mean')
    plt.title('Comparison of Total Pay by Gender and Ethnicity for the Same Job Title')
    plt.xticks(rotation=45, ha='right')
    plt.xticks(fontsize=8)
    plt.tight_layout()
    visualizations.append(plot_to_base64(plt))

    plt.figure(figsize=(15, 8))
    pay_by_department = fact_employee_pay.groupby('Department')[['Regular Pay', 'Overtime Pay', 'Benefit Pay', 'City Retirement Contributions']].sum()
    pay_by_department = pay_by_department.apply(pd.to_numeric, errors='coerce')
    row_sums = pay_by_department.sum(axis=1)
    pay_by_department = pay_by_department.div(row_sums.replace(0, 1), axis=0) * 100
    pay_by_department.plot(kind='bar', stacked=True, colormap='viridis')
    plt.xticks(rotation=90, ha='right', fontsize=6)
    plt.title('Pay Component Distribution Across Departments', fontsize=8)
    plt.tight_layout()
    visualizations.append(plot_to_base64(plt))

    return render_template('visualizations.html', visualizations=visualizations)


if __name__ == "__main__":
    app.run(debug=True)
