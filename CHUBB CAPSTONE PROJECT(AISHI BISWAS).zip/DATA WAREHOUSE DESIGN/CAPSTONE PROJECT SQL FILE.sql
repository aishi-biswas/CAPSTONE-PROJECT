---DATA WAREHOUSE DEISGN

CREATE TABLE stg_employee_pay (
    RECORD_NBR                      VARCHAR(100),                        
    PAY_YEAR                        INT,                           
    DEPARTMENT_NO                   INT,                           
    DEPARTMENT_TITLE                VARCHAR(100) ,                  
    JOB_CLASS_PGRADE                VARCHAR(100),                   
    JOB_TITLE                       VARCHAR(100),                 
    EMPLOYMENT_TYPE                 VARCHAR(100),                   
    JOB_STATUS                      VARCHAR(100),                   
    MOU                             VARCHAR(100),                   
    MOU_TITLE                       VARCHAR(100),                  
    REGULAR_PAY                     DECIMAL(15,2),                 
    OVERTIME_PAY                    DECIMAL(15,2),                 
    ALL_OTHER_PAY                   DECIMAL(15,2),                 
    TOTAL_PAY                       DECIMAL(15,2),                 
    CITY_RETIREMENT_CONTRIBUTIONS   DECIMAL(15,2),                 
    BENEFIT_PAY                     DECIMAL(15,2),                 
    GENDER                          VARCHAR(100) ,                   
    ETHNICITY                       VARCHAR(100), 
);


CREATE TABLE dim_department(
    DEPARTMENT_ID                   INT PRIMARY KEY,                 
    DEPARTMENT_NO                   INT NOT NULL,                    
    DEPARTMENT_TITLE                VARCHAR(100) NOT NULL,           
    CREATE_DATE                     DATETIME, 
    UPDATE_DATE                     DATETIME  
);


CREATE TABLE dim_job_title (
    JOB_TITLE_ID                    INT PRIMARY KEY,                 
    JOB_TITLE                       VARCHAR(100) NOT NULL,           
    CREATE_DATE                     DATETIME, 
    UPDATE_DATE                     DATETIME 
);


CREATE TABLE dim_gender (
    GENDER_ID                       INT PRIMARY KEY,                
    GENDER                          VARCHAR(100) NOT NULL,            
    CREATE_DATE                     DATETIME, 
    UPDATE_DATE                     DATETIME  
);


CREATE TABLE dim_ethnicity (
    ETHNICITY_ID                    INT PRIMARY KEY,                 
    ETHNICITY                       VARCHAR(50) NOT NULL,            
    CREATE_DATE                     DATETIME, 
    UPDATE_DATE                     DATETIME 
);


CREATE TABLE dim_record(
	RECORD_ID INT PRIMARY KEY,
	RECORD_NBR VARCHAR(100),
	CREATE_DATE DATETIME,
	UPDATE_DATE DATETIME
);


CREATE TABLE dim_employment_type (
    EMPLOYMENT_TYPE_ID               INT PRIMARY KEY,                 
    EMPLOYMENT_TYPE                  VARCHAR(50) NOT NULL,            
    CREATE_DATE                      DATETIME, 
    UPDATE_DATE                      DATETIME  
);


CREATE TABLE dim_pay_year (
    PAY_YEAR_ID                      INT PRIMARY KEY,                 
    PAY_YEAR                         INT NOT NULL,                    
    CREATE_DATE                      DATETIME, 
    UPDATE_DATE                      DATETIME  
);


CREATE TABLE fact_employee_pay (
    FACT_ID                          INT PRIMARY KEY, 
	RECORD_ID                        INT NOT NULL,
    RECORD_NBR                       VARCHAR(100) NOT NULL,                    
    DEPARTMENT_ID                    INT NOT NULL,                    
    JOB_TITLE_ID                     INT NOT NULL,                    
    GENDER_ID                        INT NOT NULL,                    
    ETHNICITY_ID                     INT NOT NULL,                    
    EMPLOYMENT_TYPE_ID               INT NOT NULL,                   
    PAY_YEAR_ID                      INT NOT NULL,                    
    REGULAR_PAY                      DECIMAL(15,2) ,         
    OVERTIME_PAY                     DECIMAL(15,2) ,          
    ALL_OTHER_PAY                    DECIMAL(15,2) ,          
    TOTAL_PAY                        DECIMAL(15,2) NOT NULL,          
    CITY_RETIREMENT_CONTRIBUTIONS    DECIMAL(15,2),                   
    BENEFIT_PAY                      DECIMAL(15,2),                   
    CREATE_DATE                      DATETIME,
    UPDATE_DATE                      DATETIME,
	CONSTRAINT fk_record FOREIGN KEY (RECORD_ID) REFERENCES dim_record(RECORD_ID) ON DELETE CASCADE,
    CONSTRAINT fk_department FOREIGN KEY (DEPARTMENT_ID) REFERENCES dim_department(DEPARTMENT_ID) ON DELETE CASCADE,
    CONSTRAINT fk_job_title FOREIGN KEY (JOB_TITLE_ID) REFERENCES dim_job_title(JOB_TITLE_ID) ON DELETE CASCADE,
    CONSTRAINT fk_gender FOREIGN KEY (GENDER_ID) REFERENCES dim_gender(GENDER_ID) ON DELETE CASCADE,
    CONSTRAINT fk_ethnicity FOREIGN KEY (ETHNICITY_ID) REFERENCES dim_ethnicity(ETHNICITY_ID) ON DELETE CASCADE,
    CONSTRAINT fk_employment_type FOREIGN KEY (EMPLOYMENT_TYPE_ID) REFERENCES dim_employment_type(EMPLOYMENT_TYPE_ID) ON DELETE CASCADE,
    CONSTRAINT fk_pay_year FOREIGN KEY (PAY_YEAR_ID) REFERENCES dim_pay_year(PAY_YEAR_ID) ON DELETE CASCADE
);


---SQL QUERY ANALYSIS---


---Find the top 10 highest-paid employees by total pay.
SELECT TOP 10 f.RECORD_NBR, f.TOTAL_PAY, d.DEPARTMENT_TITLE, jt.JOB_TITLE
FROM fact_employee_pay f
JOIN dim_department d ON f.DEPARTMENT_ID = d.DEPARTMENT_ID
JOIN dim_job_title jt ON f.JOB_TITLE_ID = jt.JOB_TITLE_ID
ORDER BY f.TOTAL_PAY DESC;

---Analyze city retirement contributions by year.
SELECT py.PAY_YEAR, 
       SUM(f.CITY_RETIREMENT_CONTRIBUTIONS) AS Total_City_Contributions
FROM fact_employee_pay f
JOIN dim_pay_year py ON f.PAY_YEAR_ID = py.PAY_YEAR_ID
GROUP BY py.PAY_YEAR
ORDER BY py.PAY_YEAR;

---Explore pay distribution by ethnicity.
SELECT e.ETHNICITY, 
       AVG(f.TOTAL_PAY) AS Avg_Total_Pay, 
       SUM(f.TOTAL_PAY) AS Total_Pay_By_Ethnicity
FROM fact_employee_pay f
JOIN dim_ethnicity e ON f.ETHNICITY_ID = e.ETHNICITY_ID
GROUP BY e.ETHNICITY
ORDER BY Avg_Total_Pay DESC;

---Identify departments with the highest overtime pay.
SELECT d.DEPARTMENT_TITLE, 
       SUM(f.OVERTIME_PAY) AS Total_Overtime_Pay
FROM fact_employee_pay f
JOIN dim_department d ON f.DEPARTMENT_ID = d.DEPARTMENT_ID
GROUP BY d.DEPARTMENT_TITLE
HAVING SUM(f.OVERTIME_PAY) > 0
ORDER BY Total_Overtime_Pay DESC;

---Analyze total pay distribution by employment type.
SELECT et.EMPLOYMENT_TYPE, 
       COUNT(f.FACT_ID) AS Employee_Count, 
       SUM(f.TOTAL_PAY) AS Total_Pay
FROM fact_employee_pay f
JOIN dim_employment_type et ON f.EMPLOYMENT_TYPE_ID = et.EMPLOYMENT_TYPE_ID
GROUP BY et.EMPLOYMENT_TYPE
ORDER BY Total_Pay DESC;

---Compare average total pay by gender.
SELECT g.GENDER, 
       AVG(f.TOTAL_PAY) AS Avg_Total_Pay, 
       SUM(f.TOTAL_PAY) AS Total_Pay_By_Gender
FROM fact_employee_pay f
JOIN dim_gender g ON f.GENDER_ID = g.GENDER_ID
GROUP BY g.GENDER
ORDER BY Avg_Total_Pay DESC;

---Find the total pay and average pay for each department.
SELECT d.DEPARTMENT_TITLE, 
       SUM(f.TOTAL_PAY) AS Total_Department_Pay, 
       AVG(f.TOTAL_PAY) AS Avg_Department_Pay
FROM fact_employee_pay f
JOIN dim_department d ON f.DEPARTMENT_ID = d.DEPARTMENT_ID
GROUP BY d.DEPARTMENT_TITLE
ORDER BY Total_Department_Pay DESC;

---Check for orphan records in the fact table.
SELECT f.FACT_ID, f.RECORD_ID, f.DEPARTMENT_ID, f.JOB_TITLE_ID, f.GENDER_ID, f.ETHNICITY_ID, f.EMPLOYMENT_TYPE_ID, f.PAY_YEAR_ID
FROM fact_employee_pay f
LEFT JOIN dim_record r ON f.RECORD_ID = r.RECORD_ID
LEFT JOIN dim_department d ON f.DEPARTMENT_ID = d.DEPARTMENT_ID
LEFT JOIN dim_job_title jt ON f.JOB_TITLE_ID = jt.JOB_TITLE_ID
LEFT JOIN dim_gender g ON f.GENDER_ID = g.GENDER_ID
LEFT JOIN dim_ethnicity e ON f.ETHNICITY_ID = e.ETHNICITY_ID
LEFT JOIN dim_employment_type et ON f.EMPLOYMENT_TYPE_ID = et.EMPLOYMENT_TYPE_ID
LEFT JOIN dim_pay_year py ON f.PAY_YEAR_ID = py.PAY_YEAR_ID
WHERE r.RECORD_ID IS NULL
   OR d.DEPARTMENT_ID IS NULL
   OR jt.JOB_TITLE_ID IS NULL
   OR g.GENDER_ID IS NULL
   OR e.ETHNICITY_ID IS NULL
   OR et.EMPLOYMENT_TYPE_ID IS NULL
   OR py.PAY_YEAR_ID IS NULL;

---Identify records with missing or null values.
SELECT *
FROM fact_employee_pay
WHERE RECORD_ID IS NULL
   OR DEPARTMENT_ID IS NULL
   OR JOB_TITLE_ID IS NULL
   OR GENDER_ID IS NULL
   OR ETHNICITY_ID IS NULL
   OR EMPLOYMENT_TYPE_ID IS NULL
   OR PAY_YEAR_ID IS NULL
   OR TOTAL_PAY IS NULL;

---Ensure all records in the fact table reference valid pay years.
SELECT f.PAY_YEAR_ID, py.PAY_YEAR, COUNT(f.FACT_ID) AS Record_Count
FROM fact_employee_pay f
LEFT JOIN dim_pay_year py ON f.PAY_YEAR_ID = py.PAY_YEAR_ID
GROUP BY f.PAY_YEAR_ID, py.PAY_YEAR
ORDER BY py.PAY_YEAR;

















